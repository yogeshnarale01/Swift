//
//  Post.swift
//  03_10_2022_JSONSerializationDemo
//
//  Created by Vishal Jagtap on 17/11/22.
//

import Foundation
struct Post{
    var id : Int
    var title: String
    var body : String
}
